// Arnav Tuli 25070521070


#include <stdio.h>
int main(){
	int inp1 , inp2;
	scanf("%d" , &inp1);
	scanf("%d" , &inp2);
	printf("%d\n" , inp1 + inp2);
	printf("%d\n" , inp1 - inp2);
	printf("%d\n" , inp1*inp2);
	printf("%d\n" , inp1 / inp2);
	printf("%d\n" , inp1 % inp2);
	return 0;
}